# types.py - generado automáticamente
import strawberry


@strawberry.type
class AccountBalances:
    pass  # TODO: completar campos manualmente


@strawberry.type
class Branches:
    pass  # TODO: completar campos manualmente


@strawberry.type
class Brands:
    pass  # TODO: completar campos manualmente


@strawberry.type
class CarBrands:
    pass  # TODO: completar campos manualmente


@strawberry.type
class CarModels:
    pass  # TODO: completar campos manualmente


@strawberry.type
class Cars:
    pass  # TODO: completar campos manualmente


@strawberry.type
class Clients:
    pass  # TODO: completar campos manualmente


@strawberry.type
class CompanyData:
    pass  # TODO: completar campos manualmente


@strawberry.type
class countries:
    pass  # TODO: completar campos manualmente


@strawberry.type
class CreditCardGroups:
    pass  # TODO: completar campos manualmente


@strawberry.type
class CreditCards:
    pass  # TODO: completar campos manualmente


@strawberry.type
class Discounts:
    pass  # TODO: completar campos manualmente


@strawberry.type
class DocTypes:
    pass  # TODO: completar campos manualmente


@strawberry.type
class Documents:
    pass  # TODO: completar campos manualmente


@strawberry.type
class documentTypes:
    pass  # TODO: completar campos manualmente


@strawberry.type
class ItemCategories:
    pass  # TODO: completar campos manualmente


@strawberry.type
class ItemPriceHistory:
    pass  # TODO: completar campos manualmente


@strawberry.type
class CategorySubcategoryItems:
    pass  # TODO: completar campos manualmente


@strawberry.type
class Itemstock:
    pass  # TODO: completar campos manualmente


@strawberry.type
class Itemsubcategories:
    pass  # TODO: completar campos manualmente


@strawberry.type
class OrderDetails:
    pass  # TODO: completar campos manualmente


@strawberry.type
class OrderHistory:
    pass  # TODO: completar campos manualmente


@strawberry.type
class OrderHistoryDetails:
    pass  # TODO: completar campos manualmente


@strawberry.type
class Orders:
    pass  # TODO: completar campos manualmente


@strawberry.type
class OrderStatus:
    pass  # TODO: completar campos manualmente


@strawberry.type
class PriceListItems:
    pass  # TODO: completar campos manualmente


@strawberry.type
class priceLists:
    pass  # TODO: completar campos manualmente


@strawberry.type
class provinces:
    pass  # TODO: completar campos manualmente


@strawberry.type
class Roles:
    pass  # TODO: completar campos manualmente


@strawberry.type
class SaleConditions:
    pass  # TODO: completar campos manualmente


@strawberry.type
class serviceType:
    pass  # TODO: completar campos manualmente


@strawberry.type
class StockHistory:
    pass  # TODO: completar campos manualmente


@strawberry.type
class Suppliers:
    pass  # TODO: completar campos manualmente


@strawberry.type
class tempOrderDetails:
    pass  # TODO: completar campos manualmente


@strawberry.type
class TempStockEntries:
    pass  # TODO: completar campos manualmente


@strawberry.type
class Transactions:
    pass  # TODO: completar campos manualmente


@strawberry.type
class transactionTypes:
    pass  # TODO: completar campos manualmente


@strawberry.type
class UserAccess:
    pass  # TODO: completar campos manualmente


@strawberry.type
class UserActions:
    pass  # TODO: completar campos manualmente


@strawberry.type
class UserActivityLog:
    pass  # TODO: completar campos manualmente


@strawberry.type
class Users:
    pass  # TODO: completar campos manualmente


@strawberry.type
class Warehouses:
    pass  # TODO: completar campos manualmente
